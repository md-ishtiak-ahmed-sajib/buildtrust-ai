# Scenario E

Run time (UTC): 2026-10-20T13:43:40.484145Z

Result: **BLOCKED**

Cash before: BDT 150000.00

Cash after: BDT 150000.00

Audit record IDs: 333, 332, 331, 330, 329

Read `scenario-e.json` for the actual requests, source records, checks and receipt, where a payment occurred. These results came from a running local API and saved database.

All companies and transfers are fictional. No real money moved.
