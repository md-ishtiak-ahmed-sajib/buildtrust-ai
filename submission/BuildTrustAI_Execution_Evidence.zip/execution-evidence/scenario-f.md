# Scenario F

Run time (UTC): 2026-10-20T13:43:40.757300Z

Result: **BLOCKED**

Cash before: BDT 1000000.00

Cash after: BDT 1000000.00

Audit record IDs: 388, 387, 386, 385, 384

Read `scenario-f.json` for the actual requests, source records, checks and receipt, where a payment occurred. These results came from a running local API and saved database.

All companies and transfers are fictional. No real money moved.
