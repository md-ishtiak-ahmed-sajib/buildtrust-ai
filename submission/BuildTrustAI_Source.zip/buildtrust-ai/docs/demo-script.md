# Demonstration script

This video shows the actual app in a separate fictional database. Narration uses the local Microsoft Zira synthetic voice. Screen actions, amounts and receipts come from the running app. No success screen or transaction reference is invented. The public demo in README uses a different separate profile.

## 0:00 - The working app

BuildTrust A I helps construction teams check costs and payments. These are real screens from the local app. The projects, suppliers and money are fictional. No bank is connected. You can try a separate public demo with the four passwords in the read me. This recording uses its own sample database.

## 0:25 - Four source records

A payment starts with four records. The bill of quantities lists approved work. A purchase order records what was ordered. A delivery receipt records what was accepted. The invoice states the supplier claim. The app reads actual files and keeps their sources. A person must confirm procurement records before they are trusted.

## 0:50 - An inflated steel invoice

This invoice claims ninety five tonnes of steel. The approved records support only eighty tonnes. The price is seventy thousand taka per tonne. The claim is six million six hundred and fifty thousand taka. The supported amount is five million six hundred thousand. The excess is one million and fifty thousand taka, or eighteen point seven five percent. The app blocks payment.

## 1:25 - A clear reason for the block

The workflow saves each check and its result. The comparison shows where the invoice differs from the records. The copilot explains the block using this saved evidence. It does not decide whether to ignore a financial rule. Instructions inside an uploaded document cannot approve a payment or give someone extra access.

## 1:50 - A valid invoice

The cement invoice is a separate example. It claims seventy thousand taka. The supplier, price, quantity and accepted delivery agree. The app also checks cash today and cash after a delay in customer receipts. The required reserve is preserved. It prepares a proposal and holds the needed cash and quantity for review.

## 2:15 - Independent approval

The Operator prepared this payment and cannot approve it. We must use a different authorized account. Approval applies to the exact amount, supplier and evidence shown here, and it has an expiry time. If important records or permissions change, the app requires fresh checks. The browser cannot bypass these server rules.

## 2:40 - One simulated payment

We sign in as Finance Manager, review the proposal and approve it. We then confirm the simulation. The app rechecks permission, evidence, cash and the reserve before saving the payment. Cash, ledger and audit records are saved together. Seventy thousand taka is paid once. One million becomes nine hundred and thirty thousand. The receipt is clearly a simulation.

## 3:10 - Prices and an estimate

A different sample project has two million taka in cash. It estimates twenty tonnes of steel at seventy thousand per tonne. We explicitly search fictional demo prices. The wrong grade cannot be selected. Choosing seventy four thousand increases the estimate by eighty thousand taka. Forecast cash falls from six hundred thousand to five hundred and twenty thousand. Recorded cash stays at two million. A different Manager checks the submitted estimate and a separate Admin approves it.

## 3:50 - Evidence and limits

The audit screen checks the saved chain. Other areas cover measurements, accounting, contracts, installments and reviewed corrections. Tests and source files are included in the package. Paid searches and professional acceptance need separate evidence. A person with full database access can rewrite a local audit chain. The team has sent its registration email. Organizer confirmation, rehearsal and final competition submission remain team actions.

For a new recording, use the isolated recording wrapper and its own generated accounts. Follow these scenes and stay below five minutes. Do not reset the working database. For a personal trial, use the separate public launcher and README passwords.

## Current implementation status

The recorded application already includes the implemented security hardening. Private privileged sign-in uses an authenticator. Local tests and the October 20 Windows/Linux hosted run passed. This narration describes working behavior, not a proposed build. The existing 4:18 recording remains valid because the application source is unchanged by this documentation refresh.
